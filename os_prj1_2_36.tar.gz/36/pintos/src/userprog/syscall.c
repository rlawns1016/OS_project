#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
/////////////////////////////////////////////////////////////////
#include "threads/vaddr.h"
#include "userprog/process.h"
#include "threads/init.h"
#include <string.h>
#include "devices/input.h"
#include "devices/shutdown.h"
#include "filesys/off_t.h"
#include "threads/synch.h"
//#include "lib/user/syscall.h"
struct file
{
	struct inode *inode;
	off_t pos;
	bool deny_write;
};
struct lock mutex;
/////////////////////////////////////////////////////////////////
static void syscall_handler (struct intr_frame *);
void syscall_init (void);

/////////////////////////////////////////////////////////////////
void exit(int status)
{
	
  struct thread *cur;
	int i;
	cur = thread_current();
	cur->exit_status = status;
	//thread_current()->exit_status = status;
	printf("%s: exit(%d)\n",thread_name(),status);

	for( i = 3; i < 128; i ++)
	{
		if(cur->fd[i] != NULL)
		{
			close(i);
		}
	}
	
	thread_exit();
}
int exec(const char *cmd_line)
{
	//pid_t = int
	return process_execute(cmd_line);
}
void halt(void)
{
	shutdown_power_off();
}

int wait(int pid)
{
	//pid_t = int
	return process_wait(pid);
}

int fibo(int n)
{
	int i, j, k, yes;
	i = 0;
	j = 1;
	k = 0;	
	if( n == 0 )
		return 0;
	if ( n == 1 )
		return 1;

	for( yes = 1; yes < n; yes++)
	{
		k = j + i;
		i = j;
		j = k;
	}

	return k;

}

int sum(int a, int b, int c, int d)
{
	printf("%d\n", a+b+c+d);
	
	return a+b+c+d;
}

bool create(const char* name, unsigned initial_size)
{
	if(!name)	exit(-1);
	return filesys_create(name, initial_size);
}

bool remove(const char *name)
{
	return filesys_remove(name);
}

int open(const char *name)
{
	struct file* fp;
	int i;
	if(name == NULL)
		exit(-1);
	fp = filesys_open(name);
	if(fp == NULL)
		return -1;
	
	for(i = 3; i < 128; i++){
			if(thread_current()->fd[i] == NULL){
				thread_current()->fd[i] = fp;
				if(strcmp(thread_current()->name, name) == 0) 
					file_deny_write(thread_current()->fd[i]);
				return i;
		}
	
	}
	return -1;
}

int filesize(int fd)
{
	return file_length(thread_current()->fd[fd]);
}

void seek(int fd, unsigned pos)
{
	file_seek(thread_current()->fd[fd], pos);
}

unsigned tell(int fd)
{
	return file_tell(thread_current()->fd[fd]);
}

void close(int fd)
{
	//struct file* fp;
	if(thread_current()->fd[fd] == NULL)
			exit(-1);
	file_close(thread_current()->fd[fd]);
	thread_current()->fd[fd] = NULL;
}

int read(int fd, void *buffer, unsigned size)
{
	check_user_vaddr(buffer);
	int i;
	if(fd == 0)
	{
		for(i = 0; i < (int)size; i++)
				*(uint8_t *)(buffer + i) = input_getc();
		if(i == (int)size)
			return size;
		else
			return -1;
	}
	else if(fd >= 3)
	{	
		return file_read(thread_current()->fd[fd], buffer, size);
	}
	return -1;

//	return i;
		
}

int write(int fd, const void *buffer, unsigned size)
{
	if(fd == 1)
	{
		putbuf(buffer,size);
		return size;
	}
	else if(fd >= 3)
	{	
		check_user_vaddr(buffer);
		return file_write(thread_current()->fd[fd], buffer, size);
	}
	return -1;
}


void check_user_vaddr(const void *addr)
{
	if(!is_user_vaddr(addr))
		exit(-1);
}
/////////////////////////////////////////////////////////////////
void
syscall_init (void) 
{
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
	lock_init(&mutex);
}

/////////////////////////////////////////////////////////////////
static void
syscall_handler (struct intr_frame *f) 
{
	int *esp;
	check_user_vaddr(f->esp);
	esp = ((int*)(f->esp));
	switch(esp[0])
	{
		case SYS_HALT:
			//syscall0
			halt();
			break;
		case SYS_EXIT:
			//syscall1
			check_user_vaddr(&esp[1]);
			exit(esp[1]);
			break;
		case SYS_EXEC:
			//syscall1
			check_user_vaddr(&esp[1]);
			f->eax = exec((const char *)esp[1]);
			break;
		case SYS_WAIT:
			//syscall1
			check_user_vaddr(&esp[1]);
			f->eax = wait((uint32_t *)esp[1]);
			break;
		case SYS_FIBO:
			check_user_vaddr(&esp[1]);
			f->eax = fibo(esp[1]);
			break;
		case SYS_SUM:
			check_user_vaddr(&esp[1]);
			check_user_vaddr(&esp[2]);
			check_user_vaddr(&esp[3]);
			check_user_vaddr(&esp[4]);			
			f->eax = sum(esp[1], esp[2], esp[3], esp[4]);
			break;
		case SYS_CREATE:
			check_user_vaddr(&esp[1]);
			check_user_vaddr(&esp[2]);
			f->eax = create((const char *)esp[1], esp[2]);
			break;
		case SYS_REMOVE:
			check_user_vaddr(&esp[1]);
			f->eax = remove((const char *)esp[1]);
			break;
		case SYS_OPEN:
			check_user_vaddr(&esp[1]);
			lock_acquire(&mutex);
			f->eax = open((const char *)esp[1]);
			lock_release(&mutex);
			break;
		case SYS_FILESIZE:
			check_user_vaddr(&esp[1]);
			f->eax = filesize(esp[1]);
			break;
		
		case SYS_READ:
			//syscall3
			check_user_vaddr(&esp[1]);
			check_user_vaddr(&esp[2]);
			check_user_vaddr(&esp[3]);
			lock_acquire(&mutex);
			f->eax = read(esp[1],(char *)esp[2],esp[3]);
			lock_release(&mutex);
			break;
		case SYS_WRITE:
			//syscall3
			check_user_vaddr(&esp[1]);
			check_user_vaddr(&esp[2]);
			check_user_vaddr(&esp[3]);
			lock_acquire(&mutex);
			f->eax = write(esp[1],(char *)esp[2],esp[3]);
			lock_release(&mutex);
			break;
		
		case SYS_SEEK:
			check_user_vaddr(&esp[1]);
			check_user_vaddr(&esp[2]);
			seek(esp[1],esp[2]);
			break;
		case SYS_TELL:
			check_user_vaddr(&esp[1]);
			f->eax = tell((unsigned)esp[1]);
			break;
		case SYS_CLOSE:
			check_user_vaddr(&esp[1]);	
			close(esp[1]);
			break;
		
			////////////////////////////////proj 2
		case SYS_MMAP:
			break;
		case SYS_MUNMAP:
			break;
			////////////////////////////////proj 3
		case SYS_CHDIR:
			break;
		case SYS_MKDIR:
			break;
		case SYS_READDIR:
			break;
		case SYS_ISDIR:
			break;
		case SYS_INUMBER:
			break;
			////////////////////////////////proj 4
	}
}

//////////////////////////////////////////////////////////////////
