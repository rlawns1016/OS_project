#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <../userprog/syscall.h>
#include <syscall.h>
int main(int argc, char* argv[])
{
		 if(argc != 5) 
			 return EXIT_FAILURE;
			 else{
			 	int result, result2;
				result = fibo(atoi(argv[1]));
				printf("%d ", result);
				result2 = sum(atoi(argv[1]),atoi(argv[2]),atoi(argv[3]),atoi(argv[4]));
			 }
			 return EXIT_SUCCESS;
}
