#ifndef USERPROG_SYSCALL_H
#define USERPROG_SYSCALL_H
int read(int fd, void *buffer, unsigned size);
void syscall_init (void);
void exit(int status);
void halt(void);
int wait(int pid);
int fibo(int n);
int sum(int a, int b, int c, int d);
int exec(const char *);
#endif /* userprog/syscall.h */
