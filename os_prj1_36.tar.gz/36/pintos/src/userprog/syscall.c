#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
/////////////////////////////////////////////////////////////////
#include "threads/vaddr.h"
#include "userprog/process.h"
#include "threads/init.h"
#include <string.h>
#include "devices/input.h"
#include "devices/shutdown.h"

/////////////////////////////////////////////////////////////////
static void syscall_handler (struct intr_frame *);
/////////////////////////////////////////////////////////////////
void exit(int status)
{
  struct thread *cur;
	cur = thread_current();
	cur->exit_status = status;
	printf("%s: exit(%d)\n",thread_name(),status);
	thread_exit();
}
int exec(const char *cmd_line)
{
	//pid_t = int
	return process_execute(cmd_line);
}
void halt(void)
{
	shutdown_power_off();
}

int wait(int pid)
{
	//pid_t = int
	return process_wait(pid);
}

int fibo(int n)
{
	int i, j, k, yes;
	i = 0;
	j = 1;
	
	if( n == 0 )
		return 0;
	if ( n == 1 )
		return 1;

	for( yes = 1; yes < n; yes++)
	{
		k = j + i;
		i = j;
		j = k;
	}

	return k;

}

int sum(int a, int b, int c, int d)
{
	printf("%d\n", a+b+c+d);
	
	return a+b+c+d;
}

int read(int fd, void *buffer, unsigned size)
{
	//fd == 0 ONLY
	if(fd == 0)
	{
		int i;
		for(i = 0; i < (int)size; i++)
			*(uint8_t *)(buffer + i) = input_getc();
		if(i == (int)size)
			return size;
		else
			return -1;
	}
	else
		return 0;
}

int write(int fd, const void *buffer, unsigned size)
{
	//fd == 1 ONLY
	if(fd == 1)
	{
		putbuf(buffer,size);
		return size;
	}
	else
		return -1;
}


void check_user_vaddr(const void *addr)
{
	if(!is_user_vaddr(addr))
		exit(-1);
}
/////////////////////////////////////////////////////////////////
void
syscall_init (void) 
{
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

/////////////////////////////////////////////////////////////////
static void
syscall_handler (struct intr_frame *f) 
{
	int *esp;
	check_user_vaddr(f->esp);
	esp = ((int*)(f->esp));
	switch(esp[0])
	{
		case SYS_HALT:
			//syscall0
			halt();
			break;
		case SYS_EXIT:
			//syscall1
			check_user_vaddr(&esp[1]);
			exit(esp[1]);
			break;
		case SYS_EXEC:
			//syscall1
			check_user_vaddr(&esp[1]);
			f->eax = exec((char *)esp[1]);
			break;
		case SYS_WAIT:
			//syscall1
			check_user_vaddr(&esp[1]);
			f->eax = wait(esp[1]);
			break;
		case SYS_FIBO:
			check_user_vaddr(&esp[1]);
			f->eax = fibo(esp[1]);
			break;
		case SYS_SUM:
			check_user_vaddr(&esp[1]);
			check_user_vaddr(&esp[2]);
			check_user_vaddr(&esp[3]);
			check_user_vaddr(&esp[4]);			
			f->eax = sum(esp[1], esp[2], esp[3], esp[4]);
			break;
		/*
		case SYS_CREATE:
			break;
		case SYS_REMOVE:
			break;
		case SYS_OPEN:
			break;
		case SYS_FILESIZE:
			break;
		*/
		case SYS_READ:
			//syscall3
			check_user_vaddr(&esp[1]);
			check_user_vaddr(&esp[2]);
			check_user_vaddr(&esp[3]);
			f->eax = read(esp[1],(char *)esp[2],esp[3]);
			break;
		case SYS_WRITE:
			//syscall3
			check_user_vaddr(&esp[1]);
			check_user_vaddr(&esp[2]);
			check_user_vaddr(&esp[3]);
			f->eax = write(esp[1],(char *)esp[2],esp[3]);
			break;
		/*
		case SYS_SEEK:
			break;
		case SYS_TELL:
			break;
		case SYS_CLOSE:
			break;
		*/
			////////////////////////////////proj 2
		case SYS_MMAP:
			break;
		case SYS_MUNMAP:
			break;
			////////////////////////////////proj 3
		case SYS_CHDIR:
			break;
		case SYS_MKDIR:
			break;
		case SYS_READDIR:
			break;
		case SYS_ISDIR:
			break;
		case SYS_INUMBER:
			break;
			////////////////////////////////proj 4
	}
}

//////////////////////////////////////////////////////////////////
